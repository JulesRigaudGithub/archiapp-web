var express = require('express'); //import de la bibliothèque Express
var app = express(); //instanciation d'une application Express

// Pour s'assurer que l'on peut faire des appels AJAX au serveur
app.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  next();
});

// Ici faut faire faire quelque chose à notre app...
// On va mettre les "routes"  == les requêtes HTTP acceptéés par notre application.

app.get("/", function(req, res) {
  res.send("Hello")
})

app.get("/test/*", function(req, res) {
  var test = req.url.substr(6);
  res.json({
    "msg": test
  })
});

var cnt = 0;

app.get("/cnt/query", (req, res) => {
  res.json(cnt);
});

app.get("/cnt/inc", (req, res) => {
  console.log(req.query);
  if ("v" in req.query) {
    if (req.query.v.match("\^[0-9]+$")) {
      cnt += parseInt(req.query.v);
      res.json({
        "code": 0
      });
    } else {
      res.json({
        "code": -1
      });
    }
  } else {
    cnt += 1;
    res.json({
      "code": 0
    })
  }
});

var allMsgs = ["Hello World", "foobar", "CentraleSupelec Forever"];

app.get("/msg/get/*", function(req, res) {
  var msg_idx_str = req.url.substr(9);
  if (msg_idx_str.match("\^[0-9]")) {
    var msg_idx = parseInt(msg_idx_str);

    if (msg_idx < allMsgs.length && msg_idx >= 0) {
      console.log("ici");
      res.json({
        "code": 1,
        "mdg": allMsgs[msg_idx]
      });
    } else {
      res.json({
        "code": 0
      });
    };
  } else {
    res.json({
      "code": 0
    });
  }
});

app.get("/msg/nber", (req, res) => {
  res.json(allMsgs.length);
});

app.get("/msg/getAll", (req, res) => {
  res.json(allMsgs);
});

app.get("/msg/post/*", (req, res) => {
  var msg = unescape(req.url.substr(10));
  allMsgs.push(msg);
  res.json(allMsgs.length - 1);
});

app.listen(8080); //commence à accepter les requêtes
console.log("App listening on port 8080...");

