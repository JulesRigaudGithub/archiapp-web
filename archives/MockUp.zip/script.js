function fact(n) {
  if (n === 0) {
    return 1;
  }
  return n * fact(n - 1);
}

console.log(fact(5));

function applique(f, tab) {
  return tab.map(f);
}

console.log(applique(fact, [1, 2, 3, 4, 5, 6]));

console.log(applique((n) => n + 1, [1, 2, 3, 4, 5, 6]))

msgs = [
  { "msg": "Hello World" },
  { "msg": "Blah Blah" },
  { "msg": "I love cats" }
];

function update(tab) {
  var ul = document.getElementById("messages");
  ul.textContent = '';
  for (var i = 0; i < tab.length; i++) {
    var li = document.createElement("li");
    li.textContent = tab[i].msg;
    ul.appendChild(li);
  }
  console.log(ul)
}

const button = document.getElementById("button-send");

button.addEventListener("click", () => update(msgs));